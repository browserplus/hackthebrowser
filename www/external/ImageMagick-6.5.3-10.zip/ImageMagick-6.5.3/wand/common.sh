SRCDIR=`dirname $0`
SRCDIR=`cd $SRCDIR && pwd`
TOPSRCDIR=`cd $srcdir && pwd`
export SRCDIR TOPSRCDIR
cd wand || exit 1
